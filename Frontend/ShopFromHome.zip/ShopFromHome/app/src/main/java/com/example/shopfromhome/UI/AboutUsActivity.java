package com.example.shopfromhome.UI;

public class AboutUsActivity {
}
