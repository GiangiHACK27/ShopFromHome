package com.example.shopfromhome.models;

public enum Ruolo {
    USER, MAGAZZINIERE
}
