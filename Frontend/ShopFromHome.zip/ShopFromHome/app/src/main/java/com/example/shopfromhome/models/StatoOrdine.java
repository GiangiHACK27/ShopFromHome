package com.example.shopfromhome.models;

public enum StatoOrdine {
    IN_LAVORAZIONE,
    PRONTO,
    RITIRATO,
    ANNULLATO
}
