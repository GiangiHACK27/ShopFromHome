package com.example.shopfromhome.ui;

import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.Matchers.is;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.matcher.ViewMatchers;

import com.example.shopfromhome.R;
import com.example.shopfromhome.UI.RegisterActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class RegisterActivityTest {

    @Rule
    public ActivityTestRule<RegisterActivity> activityRule = new ActivityTestRule<>(RegisterActivity.class);

    @Test
    public void testSuccessfulRegistration() {
        // Compila i campi di registrazione
        Espresso.onView(ViewMatchers.withId(R.id.etNome)).perform(ViewActions.typeText("Mario"));
        Espresso.onView(ViewMatchers.withId(R.id.etCognome)).perform(ViewActions.typeText("Rossi"));
        Espresso.onView(ViewMatchers.withId(R.id.etEmail)).perform(ViewActions.typeText("mario.rossi@example.com"));
        Espresso.onView(ViewMatchers.withId(R.id.etPassword)).perform(ViewActions.typeText("password123"));
        Espresso.closeSoftKeyboard();

        // Clicca sul pulsante di registrazione
        Espresso.onView(ViewMatchers.withId(R.id.btnRegistrati)).perform(ViewActions.click());

        // Verifica che il messaggio di successo venga mostrato
        Espresso.onView(ViewMatchers.withText("Registrazione riuscita!")).check(matches(isDisplayed()));

        // Verifica che l'utente venga reindirizzato alla homepage
        Espresso.onView(withId(R.id.recyclerView)) // Usa l'ID corretto della vista visibile nella homepage
                .check(matches(isDisplayed()));
    }

    @Test
    public void testEmptyFields() {
        // Lascia i campi vuoti e prova a cliccare sul pulsante di registrazione
        Espresso.onView(ViewMatchers.withId(R.id.btnRegistrati)).perform(ViewActions.click());

        // Verifica che il messaggio di errore venga mostrato
        Espresso.onView(ViewMatchers.withText("Compila tutti i campi")).check(matches(isDisplayed()));
    }
}
